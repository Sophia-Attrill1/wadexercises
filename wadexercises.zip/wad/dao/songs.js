class SongsDao {
    // conn is our mysql database connection
    // table is the table storing the students
    constructor(conn, table) {
        this.conn = conn;
        this.table = table;
    }


    // find a student with a given ID

    findArtistByName(artist) {
        return new Promise ( (resolve, reject) => {
            this.conn.query(`SELECT * FROM ${this.table} WHERE artist=?`, [artist],
                (err, results, fields) => {
                    if(err) {
                        reject(err);
                    } else if (results.length == 0) {
                        // resolve with null if no results - this is not considered an error, so we do not reject
                        resolve(null); 
                    } else {
                        // only one student will be found but "results" will still be an array with one member. 
                        // To simplify code which makes use of the DAO, extract the one and only row from the array 
                        // and resolve with that.
                        resolve(results);
                    }
                });
        });
    }
                            

    // find all students on a given course
    findTitleByName(title) {
        return new Promise ( (resolve, reject) => {
            this.conn.query(`SELECT * FROM ${this.table} WHERE title=?`, [title],
                (err, results, fields) => {
                    if(err) {
                        reject(err);
                    } else if (results.length == 0) {
                        // resolve with null if no results - this is not considered an error, so we do not reject
                        resolve(null); }
                     else {
                        resolve(results);
                    }
                });
        });
    }

    findArtistAndTitleByName(title, artist) {
        return new Promise ( (resolve, reject) => {
            this.conn.query(`SELECT * FROM ${this.table} WHERE title=? AND artist=?`, [title, artist],
                (err, results, fields) => {
                    if(err) {
                        reject(err);
                    } else if (results.length == 0) {
                        // resolve with null if no results - this is not considered an error, so we do not reject
                        resolve(null); }
                     else {
                        resolve(results);
                    }
                });
        });
    }

    findSongsById(id) {
        return new Promise ( (resolve, reject) => {
            this.conn.query(`SELECT * FROM ${this.table} WHERE id=?`, [id],
                (err, results, fields) => {
                    if(err) {
                        reject(err);
                    } else if (results.length == 0) {
                        // resolve with null if no results - this is not considered an error, so we do not reject
                        resolve(null); }
                     else {
                        resolve(results);
                    }
                });
        });
    }

    buySongByID(id) {
        return new Promise ( (resolve, reject) => {
            this.conn.query(`UPDATE ${this.table} SET quantity=quantity-1 WHERE id=?`, [id],
                (err, results, fields) => {
                    if(err) {
                        reject(err);
                    } else if (results.length == 0) {
                        // resolve with null if no results - this is not considered an error, so we do not reject
                        resolve(null); }
                     else {
                        resolve(results);
                    }
                });
        });
    }

    deleteSongById(id) {
        return new Promise ( (resolve, reject) => {
            this.conn.query(`DELETE FROM ${this.table} WHERE id=?`, [id],
                (err, results, fields) => {
                    if(err) {
                        reject(err);
                    } else if (results.affectedRows == 0) {
                        // resolve with null if no results - this is not considered an error, so we do not reject
                        resolve(null); }
                     else {
                        resolve(results);
                    }
                });
        });
    }

    // add a new student 

    createSong(title, artist, day, month, year, chart, likes, downloads, review, quantity) {
        return new Promise ( (resolve, reject) => {
            this.conn.query(`INSERT INTO ${this.table}(title, artist, day, month, year, chart, likes, downloads, review, quantity) VALUES (?,?,?,?,?,?,?,?,?,?)`, [title, artist, day, month, year, chart, likes, downloads, review, quantity],
                (err, results, fields) => {
                    if(err) {
                        reject(err);
                    } else {
                        resolve(results.insertId); // resolve with the record's allocated ID
                    }
                });
        });
    }

  


}

module.exports = SongsDao; // so that other code can use it