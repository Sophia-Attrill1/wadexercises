class ArtistDao {
    // conn is our mysql database connection
    // table is the table storing the students
    constructor(conn, table) {
        this.conn = conn;
        this.table = table;
    }

    findHometownByArtistName(artist) {
        return new Promise ( (resolve, reject) => {
            this.conn.query(`SELECT lat, lon, hometown FROM ${this.table} WHERE name=?`, [artist],
                (err, results, fields) => {
                    if(err) {
                        reject(err);
                    } else if (results.length == 0) {
                        // resolve with null if no results - this is not considered an error, so we do not reject
                        resolve(null); }
                     else {
                        resolve(results);
                    }
                });
        });
    }

    createArtist(name, lat, lon, hometown) {
        return new Promise ( (resolve, reject) => {
            this.conn.query(`INSERT INTO ${this.table}(name, lat, lon, hometown) VALUES (?,?,?,?)`, [name, lat, lon, hometown],
                (err, results, fields) => {
                    if(err) {
                        reject(err);
                    } else {
                        resolve(results.insertId); // resolve with the record's allocated ID
                    }
                });
        });
    }

}

module.exports = ArtistDao; // so that other code can use it