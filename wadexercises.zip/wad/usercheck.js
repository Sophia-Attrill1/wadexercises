const mysql = require('mysql2');
const con = require('./mysqlconn');

function usersMiddleware(req,res,next) {
    
    if(process.env.APP_USER === undefined) {
        // process.env.APP_USER does not exist (it's undefined)
        // Return a 401 (Unauthorized) HTTP code, with a JSON error message
        res.status(401).json({error: "You're not logged in. Go away!"});
    } else {
        // username exists, carry on...
        con.query(`SELECT * FROM ht_users WHERE user=?`,
        [process.env.APP_USER], (error, results, fields) => {
            if (error) {
                res.status(500).json({ error: error });
            } else {
                res.json(results);
                if (results.length == 0){
                    res.status(404).json({ error: error });
                }
            }
        });


        next();
        
    }
    
};

module.exports = usersMiddleware;