const express = require('express');
const app = express();
const mysql = require('mysql2');
const util = require("util");
const cors = require('cors');
const expressSession = require('express-session');
const MySQLStore = require('express-mysql-session')(expressSession);
app.use(express.urlencoded({extended: false}));
// require mysql connection from external module, as per last week

// use connection to create the session store. Note we have to use the connection in promise-based mode




app.use(cors());
app.use(express.static('public'));
const con = require('./mysqlconn');
const sessionStore = new MySQLStore({ } , con.promise());
require('dotenv').config();




app.use(expressSession({
    // Specify the session store to be used.
    store: sessionStore, 

    // a secret used to digitally sign session cookie, use something unguessable (e.g. random bytes as hex) in a real application.
    secret: 'BinnieAndClyde', 

    // use as recommended by your chosen session store - related to internals of how session stores work
    resave: false, 

    // save session to store before modification
    saveUninitialized: false, 

    // reset cookie for every HTTP response. The cookie expiration time will be reset, to 'maxAge' milliseconds beyond the time of the response. 
    // Thus, the session cookie will expire after 10 mins of *inactivity* (no HTTP request made and consequently no response sent) when 'rolling' is true.
    // If 'rolling' is false, the session cookie would expire after 10 minutes even if the user was interacting with the site, which would be very
    // annoying - so true is the sensible setting.
    rolling: true, 

    // destroy session (remove it from the data store) when it is set to null, deleted etc
    unset: 'destroy', 

    // useful if using a proxy to access your server, as you will probably be doing in a production environment: this allows the session cookie to pass through the proxy
    proxy: true, 

    // properties of session cookie
    cookie: { 
        maxAge: 600000, // 600000 ms = 10 mins expiry time
        httpOnly: false // allow client-side code to access the cookie, otherwise it's kept to the HTTP messages
    }
}));

app.use(express.json());

app.post('/login', (req, res) => {
    con.query(`SELECT * FROM ht_users WHERE username=? AND password=?`,
        [req.body.username, req.body.password],  (error, results, fields) => {
            if (error) {
                res.status(500).json({ error: error });
            } else if(results.length == 1){
                req.session.username = req.body.username; 
                res.json({"username": req.body.username});
            } else{
                res.status(401).json({error: "Incorrect login!"});
            }
        });

});

// Logout route
app.post('/logout', (req, res) => {
req.session = null;
res.json({'success': 1 });
});

// 'GET' login route - useful for clients to obtain currently logged in user
app.get('/login', (req, res) => {
res.json({username: req.session.username || null} );
});


app.use( (req, res, next) => {
    if(["POST", "DELETE"].indexOf(req.method) == -1) {
        next();
    } else {
        if(req.session.username) { 
            next();
        } else {
            res.status(401).json({error: "You're not logged in. Go away!"});
        }
    }
    });


// const usercheck = require('./usercheck');
// app.post('*', usercheck);

// app.use('/users', usercheck);

const usersRouter = require('./routes/users');
app.use('/users', usersRouter);


const songsRouter = require('./routes/songs');
app.use('/songs', songsRouter);

// Login route

// Middleware which protects any routes using POST or DELETE from access by users who are are not logged in





app.listen(3000);
