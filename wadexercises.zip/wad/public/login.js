async function ajaxSearchDom(username, password) {
    try {


    

   


                
                    const response2 = await fetch(`http://localhost:3000/login`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({'username': username, 'password': password}),
                    });
                    
            if (response2.status == 200){
            document.getElementById('logindiv').innerHTML = "Logged in successfully";
            }
            else if (response2.status == 401){
                document.getElementById('logindiv').innerHTML = "Incorrect Login";
            }
            else {
                document.getElementById('logindiv').innerHTML = "Error";
            }






        
    } catch (e) {
        alert(`There was an error: ${e}`);
    }

}

document.getElementById('loginbutton').addEventListener('click', () => {

    const usernamevalue = document.getElementById('username').value;
    const passwordvalue = document.getElementById('password').value;
    ajaxSearchDom(usernamevalue, passwordvalue);
});

