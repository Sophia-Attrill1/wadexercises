// index.js - CLIENT SIDE code, runs in the browser


// function ajaxSearch(artist) {
//     fetch(`http://localhost:3000/artist/${artist}`)
//         .then(response => response.text())
//         .then(text => {
//             document.getElementById('results').innerHTML = text;
//         })
//         .catch(e => { alert(`An error occurred: ${e}`); } );
// }

// async function ajaxSearch(artist) {
//     try {
//         // Send a request to our remote URL
//         const response = await fetch(`http://localhost:3000/artist/${artist}`);

//         // Parse the JSON.
//         const artistinfo = await response.json();

//         // Loop through the array of JSON objects and add the results to a <div>
//         let html = "<table><tr><th>Title</th><th>Artist</th><th>Downloads</th><th>Year</th></tr>";
//         artistinfo.forEach ( artist => {
//             let year = artist.year;
//             if(year < 2000){
//                 html += `<tr><td> ${artist.title} </td><td>${artist.artist} </td> <td>${artist.downloads} </td> <td>${artist.year} Classic Hit</td><tr/>`;
//             } else{
//                 html += `<tr><td> ${artist.title} </td><td>${artist.artist} </td> <td>${artist.downloads} </td> <td>${artist.year} </td><tr/>`;
//             }
//         });
//         html += "</table>"
//         document.getElementById('results').innerHTML = html;
//     } catch (e) {
//         alert(`There was an error: ${e}`);
//     }
// }



createLoginForm()

async function createLoginForm() {
    document.getElementById("logindiv").innerHTML = `<form>
    <label for="username">Username</label>
    <input type='text' id='username' />
    <label for="password">Password</label>
    <input type='text' id='password' />
    <input type="button" id="loginbutton" value="login" />
    </form>`

    document.getElementById('loginbutton').addEventListener('click', () => {

        const usernamevalue = document.getElementById('username').value;
        const passwordvalue = document.getElementById('password').value;
        loginfunction(usernamevalue, passwordvalue);
    });

}



const map = L.map("map1");

const attrib = "Map data copyright OpenStreetMap contributors, Open Database Licence";

L.tileLayer
    ("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
        { attribution: attrib }).addTo(map);

map.setView([51, 0.7], 13);

map.on("click", async (e) => {
    // "e.latlng" is an object (of type L.LatLng) representing the mouse click 
    // position
    // It has two properties, "lat" is the latitude and "lng" is the longitude.
    alert(`You clicked at:${e.latlng.lat} ${e.latlng.lng}`);

    const artistname = prompt('Please enter an artist name');
    const artisthometown = prompt('Please enter a home town');

    const newartist = {
        name: artistname,
        lat: e.latlng.lat,
        lon:  e.latlng.lng,
        hometown: artisthometown
    };

    if (newartist.name == null || newartist.hometown == null ){
        alert("why have you entered null values??")
        return
    }

    const response4 = await fetch(`http://localhost:3000/songs/artist/create`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(newartist)
                    });
                    
    if (response4.status == 200){
        L.marker([e.latlng.lat, e.latlng.lng]).addTo(map);

    } else {
        alert("could not find");
    }
    
});



async function ajaxSearchDom(artist) {
    try {

        const response = await fetch(`http://localhost:3000/songs/artist/${artist}`);
        if (response.status == 404) {
            alert("The song was not found");
        } else {

            const artistinfo = await response.json();
            console.log(artistinfo)

            artistinfo.forEach(song => {

                var node1 = document.createElement("p");

                var text1 = document.createTextNode
                    (`${song.title} ${song.artist}`);

                node1.appendChild(text1);
                var node2 = document.createElement("input");

                node2.setAttribute("type", "button");
                node2.setAttribute("id", "buyButton");
                node2.setAttribute("value", "newbutton");

                document.getElementById('results').appendChild(node1);
                document.getElementById('results').appendChild(node2);



                node2.addEventListener('click', async (e) => {
                    const response2 = await fetch(`http://localhost:3000/songs/songs/${song.ID}/buy`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                    });

                    if (response2.status == 200){
                            alert("Bought successfully");
                        }
                        else if (response2.status == 401){
                            alert("Incorrect Login");
                        }
                        else {
                            alert("Error");
                        }

                    

                });

                





            });
        }
    } catch (e) {
        alert(`There was an error: ${e}`);
    }

}

document.getElementById('ajaxSearchDom').addEventListener('click', () => {

    const artistvalue = document.getElementById('artist').value;
    ajaxSearchDom(artistvalue);
});

async function wherefunction(artist) {
    try {

        const response3 = await fetch(`http://localhost:3000/songs/hometown/${artist}`);
        if (response3.status == 404) {
            alert("The song was not found");
        } else {

            const artistinfo2 = await response3.json();

            const latitude = artistinfo2.lat
            const longitude = artistinfo2.lon
            const hometown = artistinfo2.hometown
            

            map.setView([latitude, longitude], 13);
            const marker = L.marker([latitude, longitude]).addTo(map);
            marker.bindPopup(`${artist} lives at ${hometown}`);



        }
    } catch (e) {
        alert(`There was an error: ${e}`);
    }

}

document.getElementById('whereButton').addEventListener('click', async (e) => {
    const artistvalue = document.getElementById('artist').value;
    wherefunction(artistvalue);


});

async function loginfunction(username, password) {
    try {


    

   


                
                    const response2 = await fetch(`http://localhost:3000/login`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({'username': username, 'password': password}),
                    });
                    
            if (response2.status == 200){
                const logininfo = await response2.json()
                const name = logininfo.username
            document.getElementById('logindiv').innerHTML = `Logged in as ${name} <input type="button" value="Logout" id="logoutBtn"/>`;
                document.getElementById('logoutBtn').addEventListener('click', async() => {
                    const response10 = await fetch(`http://localhost:3000/logout`, {
                    method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                    });
                    if (response10.status == 200){
                        createLoginForm()
                    }
                        
                
                
                });

            
            }
            else if (response2.status == 401){
                document.getElementById('logindiv').innerHTML = "Incorrect Login";
            }
            else {
                document.getElementById('logindiv').innerHTML = "Error";
            }






        
    } catch (e) {
        alert(`There was an error: ${e}`);
    }

}








