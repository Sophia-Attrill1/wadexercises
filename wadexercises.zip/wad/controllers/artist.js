const ArtistDao = require('../dao/artist.js'); 

class ArtistController {
    constructor(db) {
        // Create a DAO for communicating with the database
        this.dao = new ArtistDao(db, "artists");
    }

    async findHometownByArtistName(req, res) {
        try {
             const songs = await this.dao.findHometownByArtistName(req.params.artist);
             if (error) {
                res.status(500).json({ error: error });
            } 
            else if (songs == null){
                res.status(404).json({error: "No artist with that name"});
            }
            else {
                res.json(songs);
            }
            res.json(songs);    
        } catch(e) {
            res.status(500).json({error: e});
        }
    }

    async createArtist(req, res) {
        try {
             const songs = await this.dao.createArtist(req.body.name, req.body.lat, req.body.lon, req.body.hometown);
             if (error) {
                res.json({id: songs});
            } else {
                res.json({ success: 1 });
            }
        } catch(e) {
            res.status(500).json({error: e});
        }
    }


}

module.exports = ArtistController; // so that other code can use it