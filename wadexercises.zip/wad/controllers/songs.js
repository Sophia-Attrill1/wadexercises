const SongDao = require('../dao/songs'); 

class SongsController {
    constructor(db) {
        // Create a DAO for communicating with the database
        this.dao = new SongDao(db, "wadsongs");
    }

    // findStudentById()
    // calls the DAO's findStudentById() method, passing the ID parameter to
    // it, and formats the JSON returned.
    async findArtistByName(req, res) {
        try {
            const songs = await this.dao.findArtistByName(req.params.artist);
            // Remember from the DAO that the promise resolves with null if there are no results
            if (!songs) return res.status(404).json({error: "no songs found!"})
            else return res.json(songs)
          } catch (e) {
            console.log(e);
            res.status(500).json({ error: e.message });
          }
    }

    // findStudentByCourse()
    // calls the DAO's findStudentByCourse() method, passing the course parameter to
    // it, and formats the JSON returned.
    async findTitleByName(req, res) {
        try {
             const songs = await this.dao.findTitleByName(req.params.title);
             if (!songs) return res.status(404).json({error: "no songs found!"})
            else return res.json(songs)
          } catch (e) {
            console.log(e);
            res.status(500).json({ error: e.message });
          }
    
    }

    async findArtistAndTitleByName(req, res) {
        try {
             const songs = await this.dao.findArtistAndTitleByName(req.params.title, req.params.artist);
             if (!songs) return res.status(404).json({error: "no songs found!"})
            else return res.json(songs)
          } catch (e) {
            console.log(e);
            res.status(500).json({ error: e.message });
          }
    
    }

    async findSongsById(req, res) {
        try {
             const songs = await this.dao.findSongsById(req.params.id);
             if (!songs) return res.status(404).json({error: "no songs found!"})
            else return res.json(songs)
          } catch (e) {
            console.log(e);
            res.status(500).json({ error: e.message });
          }
    
    }

    async buySongByID(req, res) {
        try {
             const songs = await this.dao.buySongByID(req.params.id);
             if (!songs) return res.status(404).json({error: "no songs found!"})
            else return res.json(songs)
          } catch (e) {
            console.log(e);
            res.status(500).json({ error: e.message });
          }
    
    }

    async deleteSongById(req, res) {
        try {
             const songs = await this.dao.deleteSongById(req.params.id);
             if (!songs) return res.status(404).json({error: "no songs found!"})
            else return res.json({ 'message': 'Successfully deleted.' })
          } catch (e) {
            console.log(e);
            res.status(500).json({ error: e.message });
          }
    
    }

    async createSong(req, res) {
        try {
             const songs = await this.dao.createSong(req.body.title, req.body.artist, req.body.day, req.body.month, req.body.year, req.body.chart, req.body.likes, req.body.downloads, req.body.review, req.body.quantity);
             if (!songs) return res.status(404).json({error: "could not create song"})
            else return res.json(res.json({id: songs}))
          } catch (e) {
            console.log(e);
            res.status(500).json({ error: e.message });
          }
    }

    

    // addStudent()
    // calls the DAO's addStudent() method, passing in the 'name' and 'course'
    // POST data to it, and formats the allocated ID as JSON to send back to the client.

}

module.exports = SongsController; // so that the router can use it