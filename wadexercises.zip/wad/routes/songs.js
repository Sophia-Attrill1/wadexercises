const express = require('express');
const songsRouter = express.Router();


// include our database connection, note that .. means "go up a folder" so the 
// mysqlconn.js is in the parent folder to the routes folder
const db = require('../mysqlconn'); 

// assume the StudentController is inside a 'student.js' file within the 
// 'controllers' folder of the project, as described above
const SongsController = require('../controllers/songs'); 


// Create the controller object, and pass in the database connection as an argument
const sController = new SongsController(db);
//use ../ because we are in a subfolder and we need to go back into to the main folder to get the connection


songsRouter.get('/artist/:artist', sController.findArtistByName.bind(sController));


songsRouter.get('/title/:title', sController.findTitleByName.bind(sController));


songsRouter.get('/title/:title/artist/:artist', sController.findArtistAndTitleByName.bind(sController));


songsRouter.get('/songs/:id', sController.findSongsById.bind(sController));


songsRouter.post('/songs/:id/buy', sController.buySongByID.bind(sController));


songsRouter.delete('/delsong/:id', sController.deleteSongById.bind(sController));


songsRouter.post('/song/create', sController.createSong.bind(sController));


module.exports = songsRouter;