const express = require('express');
const usersRouter = express.Router();
const con = require('../mysqlconn');
//use ../ because we are in a subfolder and we need to go back into to the main folder to get the connection

usersRouter.get('/allUsers', (req, res) => {
    con.query(`SELECT * FROM ht_users`,
         (error, results, fields) => {
            if (error) {
                res.status(500).json({ error: error });
            } else {
                res.json(results);
            }
        });

});

//use users/allUsers when searching

usersRouter.get('/user/:username', (req, res) => {
    con.query(`SELECT * FROM ht_users WHERE username=?`,
        [req.params.username], (error, results, fields) => {
            if (error) {
                res.status(500).json({ error: error });
            } else {
                res.json(results);
            }
        });

});

module.exports = usersRouter;