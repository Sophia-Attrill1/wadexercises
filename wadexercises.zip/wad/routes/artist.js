const express = require('express');
const artistRouter = express.Router();


// include our database connection, note that .. means "go up a folder" so the 
// mysqlconn.js is in the parent folder to the routes folder
const db = require('../mysqlconn'); 

// assume the StudentController is inside a 'student.js' file within the 
// 'controllers' folder of the project, as described above
const ArtistController = require('../controllers/artist'); 


// Create the controller object, and pass in the database connection as an argument
const sController = new ArtistController(db);


songsRouter.get('/hometown/:artist', sController.findHometownByArtistName.bind(sController));

songsRouter.post('/artist/create', sController.createArtist.bind(sController));

module.exports = artistRouter;